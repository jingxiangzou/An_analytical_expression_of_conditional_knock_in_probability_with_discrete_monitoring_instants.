本文件夹包含本项目的全部文件，列举如下

1. README
2. 报告：离散观察下的敲入概率.pdf
3. Analytical expression and the Monte Carlo simulation.py
4. sresinf.xlsx
5. data analysis.py

其中文件3和文件5是本项目对应的代码文件
执行文件3可以得到包含模拟生成的3200个对应不同volatility/instants/期末价格S1 的敲入概率以及对应的解析式计算出的概率
文件4是文件3生成的一个例子
文件5利用文件4（或者其他文件3执行生成的.xslx文件）执行，它进行数据分析并生成7个图表。文件2利用了这些图表

